// Add interactivity for toggles and feedback
document.addEventListener('DOMContentLoaded', () => {
    // Feature Detail Hover
    const featureItems = document.querySelectorAll('.features li');
    const featureDetail = document.getElementById('feature-detail');

    featureItems.forEach(item => {
        item.addEventListener('mouseover', () => {
            featureDetail.textContent = item.getAttribute('data-detail');
            featureDetail.style.display = 'block';
        });

        item.addEventListener('mouseleave', () => {
            featureDetail.style.display = 'none';
        });
    });

    // Section Collapse/Expand
    const toggleButtons = document.querySelectorAll('.toggle-btn');
    toggleButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetId = button.getAttribute('data-target');
            const targetElement = document.getElementById(targetId);

            if (targetElement.style.display === 'none' || !targetElement.style.display) {
                targetElement.style.display = 'block';
                button.textContent = 'Hide';
            } else {
                targetElement.style.display = 'none';
                button.textContent = 'Show';
            }
        });
    });

    // Feedback Submission
    const feedbackInput = document.getElementById('feedback-input');
    const feedbackList = document.getElementById('feedback-list');
    const submitFeedbackButton = document.getElementById('submit-feedback');

    submitFeedbackButton.addEventListener('click', () => {
        const feedbackText = feedbackInput.value.trim();
        if (feedbackText) {
            const listItem = document.createElement('li');
            listItem.textContent = feedbackText;
            feedbackList.appendChild(listItem);
            feedbackInput.value = '';
        } else {
            alert('Please enter your feedback before submitting!');
        }
    });
});
