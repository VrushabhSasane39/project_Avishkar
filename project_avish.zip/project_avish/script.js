
function toggleMenu() {
    const menu = document.querySelector('.menu');
    menu.classList.toggle('open');
}

document.addEventListener('DOMContentLoaded', function() {
    const toggleButton = document.querySelector('.menu-toggle');
    const menu = document.querySelector('.menu');

    toggleButton.addEventListener('click', function() {
        menu.classList.toggle('open');
    });

    document.querySelectorAll('.menu a').forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth < 768) {
                menu.classList.remove('open');
            }
        });
    });
});




document.querySelectorAll('.menu a').forEach(link => {
    link.addEventListener('click', () => {
        const menu = document.querySelector('.menu');
        if (menu.classList.contains('open')) {
            menu.classList.remove('open');
        }
    });
});

document.querySelectorAll('.kanban-ticket').forEach(ticket => {
    ticket.draggable = true;
    ticket.addEventListener('dragstart', (e) => {
        e.target.classList.add('dragging');
    });
    ticket.addEventListener('dragend', (e) => {
        e.target.classList.remove('dragging');
    });
});

document.querySelectorAll('.kanban-tickets').forEach(column => {
    column.addEventListener('dragover', (e) => {
        e.preventDefault();
        const dragging = document.querySelector('.dragging');
        column.appendChild(dragging);
    });
});



document.addEventListener('click', function(event) {
    const menu = document.querySelector('.menu');
    const toggleButton = document.querySelector('.menu-toggle');
    let targetElement = event.target; // clicked element

    do {
        if (targetElement === menu || targetElement === toggleButton) {
            
            return;
        }
    
        targetElement = targetElement.parentNode;
    } while (targetElement);

    
    if (menu.classList.contains('open')) {
        menu.classList.remove('open');
    }
});
